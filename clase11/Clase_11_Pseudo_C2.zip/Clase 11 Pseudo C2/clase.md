# Pseudoselectores
## Pseudoclases

### De enlace:
:visited
:active 

### De input
:focus: dentro
:disabled
:enabled
:target
:invalid
:valid
:required
:checked => checkbox y radio

### Cualquier elemento
:hover sobre
:nt-child() grupo de hermanos


## Psudoelemento : contenido
::after y ::before => porpiedad content
::first-letter
::first-line

## Sintaxis
div:pseudoclase::pseudoelemento