# Clase 6
## Background
- background-color
- background-image
- background-repeat
- background-position
- background-attachment
- background-size

## Fonts
- genéricas
- web 
- locales

## íconos
fontawesome
